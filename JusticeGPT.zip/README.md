# JusticeGPT

Kuritegude paragrahvide ja karistuste ennustaja Eesti seaduste põhjal.

## Kasutamine
```bash
pip install -r requirements.txt
python main.py
```
